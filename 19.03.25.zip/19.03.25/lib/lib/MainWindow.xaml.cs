﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace lib
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadReaders();
        }

        private void LoadReaders()
        {
            try
            {
                using (pdeEntities db = new pdeEntities())
                {
                    var readers = db.Readers.ToList();

                    List<ReaderInfo> readerInfos = new List<ReaderInfo>();

                    foreach (var reader in readers)
                    {
                        readerInfos.Add(new ReaderInfo
                        {
                            full_name = reader.full_name,
                            library_card_number = reader.library_card_number,
                            BooksOnLoan = 0,
                            shtraf = 0
                        });
                    }

                    ReadersDataGrid.ItemsSource = readerInfos;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}");
            }
        }

        public class ReaderInfo
        {
            public string full_name { get; set; }
            public string library_card_number { get; set; }
            public int BooksOnLoan { get; set; }
            public decimal shtraf { get; set; }
        }
    }
}